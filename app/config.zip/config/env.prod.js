const API_URL = "https://staging.cargolink.co.th/"
const API_URL_PROD = "test"
module.exports = {
    API_URL,
    API_URL2
}