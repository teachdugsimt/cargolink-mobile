const API_URL = "https://staging.cargolink.co.th/"
const API_URL_DEV = "test"
module.exports = {
    API_URL,
    API_URL_DEV
}